public interface ThreeDShape extends GeometricShape {
    public double volume();
}
