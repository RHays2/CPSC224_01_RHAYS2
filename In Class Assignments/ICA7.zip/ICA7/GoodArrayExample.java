// You should add statements to this code as needed, so that
// the code compiles correctly, and runs without error.

class GoodArrayExample {
    public static void main(String[] args) {
        GeometricShape[] geoshapes;
        ....
        geoshapes[0] = new Circle(1.0);
        geoshapes[1] = new Cone(2.0, 3.0);
    }
}
