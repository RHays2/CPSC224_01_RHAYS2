// interface for geometric shapes of all kinds

public interface GeometricShape {
    public void describe();
}
